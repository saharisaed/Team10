
package com.example.myapplication00;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication00.Classes.ElderlyClass;
import com.example.myapplication00.Classes.User;

import java.util.List;

public class Caretaker_WorkAdapter extends ArrayAdapter<ElderlyClass> {

    private List<ElderlyClass> contactList;
    private Context context;

    public Caretaker_WorkAdapter(Context ctx, List<ElderlyClass> data){
        super(ctx,R.layout.card_caretakers);
        this.contactList = data;
        this.context = ctx;
    }

    //Setting the elderly people information for the caretaker user
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        final int pos = position;
        LayoutInflater inflater=LayoutInflater.from(context);
        View v=inflater.inflate(R.layout.card_caretakers, null,false);

        //getting the id
        TextView firstName =  (TextView) v.findViewById(R.id.namegetC);
        TextView lastName = (TextView)  v.findViewById(R.id.lastNamegetC);
        TextView userType = (TextView) v.findViewById(R.id.userTypegetC);
        TextView id = (TextView) v.findViewById(R.id.idgetC);



        //buttons for calling or check elderly person
        //we will set the functions later
        Button callbtn = (Button) v.findViewById(R.id.Call);
        Button checkbtn = (Button) v.findViewById(R.id.Check);


        //setting the details in the card view
        User user= contactList.get(pos);
        firstName.setText(user.getFirstName());
        lastName.setText(user.getLastName());
        id.setText(user.getId());
        userType.setText(user.getUserType());


        return v;
    }

    @Override
    public int getCount() {
        return contactList.size();
    }

    @Nullable
    @Override
    public ElderlyClass getItem(int position) {
        return contactList.get(position);
    }
}
