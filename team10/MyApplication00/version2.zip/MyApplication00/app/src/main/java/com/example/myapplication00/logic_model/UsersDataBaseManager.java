package com.example.myapplication00.logic_model;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.myapplication00.Classes.Caretaker;
import com.example.myapplication00.Classes.ElderlyClass;
import com.example.myapplication00.Classes.Medicine;
import com.example.myapplication00.Classes.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Data base manager
public class UsersDataBaseManager {

    private static UsersDataBaseManager instance = null;
    private Context context = null;
    private UsersSQLiteDB db = null;
    private User selectedUser = null;
    //the user that we select to update
    public FirebaseUser user;
    public  FirebaseFirestore df;
    List<Caretaker> caretakers=new ArrayList<>();
    List<User> managers=new ArrayList<>();
    List<ElderlyClass> elderlies=new ArrayList<>();


    public static UsersDataBaseManager getInstance() {
        if (instance == null) {
            instance = new UsersDataBaseManager();
        }
        return instance;
    }



    public UsersSQLiteDB getDb() {
        return db;
    }

    //get the data from the fireBase
    public void getData(){
        //to get the data of the caretakers from the FireBase
        getCaretakersData();
        getManagerData();
        getElderliesData();

    }

    //delete user from the Firebase
    public void deleteUser(User user,String type){
        df.collection(type).document(user.getId())
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("TAG", "DocumentSnapshot successfully deleted!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error deleting document", e);
                    }
                });
    }


    //update user from the Firebase
    public void updateUser(User user,String type){
        df.collection("type").document(user.getId())
                .set(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("TAG", "DocumentSnapshot successfully updated!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error updated document", e);
                    }
                });
    }


    //to get the data of the elderly persons from the FireBase
    public void getElderliesData(){
        Task<QuerySnapshot> caretakers =df.collection("elderlies")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()) {
                            for(QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());
                                addElderly(document);

                            }
                        } else {
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                } ) ;

    }

    //to get the data of the caretakers from the FireBase
    public void getCaretakersData(){
        Task<QuerySnapshot> caretakers =df.collection("caretakers")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()) {
                            for(QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());
                                addCaretaker(document);

                            }
                        } else {
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                } ) ;

    }

    //to get the data of the manager from the FireBase
    public void getManagerData(){
        Task<QuerySnapshot> managers =df.collection("managers")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()) {
                            for(QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());
                                addManager(document);

                            }
                        } else {
                            Log.w("TAG", "Error getting documents.", task.getException());
                        }
                    }
                } ) ;

    }

    //add user to the list caretaker
    public Boolean addToList(User u)
    {
        //check witch user is he
        if(u.getUserType().equals("caretaker")){
            if(!caretakers.contains((Caretaker) u))
               return caretakers.add((Caretaker) u);
        }

        if(u.getUserType().equals("manager")){
            if(!managers.contains(u))
               return managers.add(u);
        }

        //adding for the elderly person
        if(u.getUserType().equals("elderly Person")){
            if(!elderlies.contains(u))
               return elderlies.add((ElderlyClass) u);
        }
        return false;
    }

    //delete from the list
    public void deleteList(User u)
    {
        //check witch user is he
        if(u.getUserType().equals("caretaker")){
            if(caretakers.contains((Caretaker) u))
                caretakers.remove((Caretaker) u);
        }

        if(u.getUserType().equals("manager")){
            if(!managers.contains(u))
                managers.remove(u);
        }

        if(u.getUserType().equals("elderly Person")){
            if(!elderlies.contains(u))
                elderlies.remove(u);
        }

    }

    //getting the data from the document map and convert it to caretaker object
    public void addCaretaker(QueryDocumentSnapshot document ){

        Map<String,Object> mymap=document.getData();
        Caretaker c;
        //getting the fields
        String firstName = (String) mymap.get("firstName");
        String lastName = (String) mymap.get("lastName");
        String id= (String) mymap.get("id");
        String userType=(String) mymap.get("userType");
        String password= (String)mymap.get("password");
        String phoneNum= (String)mymap.get("phoneNum");
        String email= (String)mymap.get("email");

        List<Date> holidays= (List<Date>) mymap.get("holidays");
        //month,payment
        HashMap<Integer,Double> payment_per_month = (HashMap<Integer, Double>) mymap.get("payment_per_month");
        String max_num_of_holidays  = (String)mymap.get("max_num_holidays");
        String price_per_day = (String) mymap.get("price_per_day");
        c=new Caretaker(firstName,lastName,id,userType,password,phoneNum,email,holidays,payment_per_month,max_num_of_holidays,price_per_day);
        caretakers.add(c);
        //add to the dp
        addCaretaker1(c);


    }

    //getting the data from the document map and convert it to elderly object
    public void addElderly(QueryDocumentSnapshot document ){

        Map<String,Object> mymap=document.getData();
        ElderlyClass elderly;
        //getting the fields
        String firstName = (String) mymap.get("firstName");
        String lastName = (String) mymap.get("lastName");
        String id= (String) mymap.get("id");
        String userType=(String) mymap.get("userType");
        String password= (String)mymap.get("password");
        String phoneNum= (String)mymap.get("phoneNum");
        String email= (String)mymap.get("email");

        //fields for the elderly person object
        List<Medicine> medicines= (List<Medicine>) mymap.get("medicines");
        String age  = (String)mymap.get("age");
        String address = (String) mymap.get("address");
        String birthday= (String) mymap.get("birthday");
        String assisPhone= (String) mymap.get("assisPhone");
        elderly=new ElderlyClass(firstName,lastName,id,userType,password,phoneNum,email,birthday,age,assisPhone,address,medicines);
        elderlies.add(elderly);

        //add to the dp
        addElderly1(elderly);

    }

    //getting the data from the document map and convert it to manager(User) object
    public void addManager(QueryDocumentSnapshot document ){

        Map<String,Object> mymap=document.getData();
        User m;
        //getting the fields
        String firstName = (String) mymap.get("firstName");
        String lastName = (String) mymap.get("lastName");
        String id= (String) mymap.get("id");
        String userType=(String) mymap.get("userType");
        String password= (String)mymap.get("password");
        String phoneNum= (String)mymap.get("phoneNum");
        String email= (String)mymap.get("email");

        m=new User(firstName,lastName,id,userType,password,phoneNum,email);
        managers.add(m);
        //add to dp
        addManager1(m);

    }


    public FirebaseUser getUser() {
        return user;
    }

    public void setUser(FirebaseUser user) {
        this.user = user;
    }

    public static void releaseInstance() {
        if (instance != null) {
            instance.clean();
            instance = null;
        }
    }

    private void clean() {

    }


    public Context getContext() {
        return context;

    }

    public void openDataBase(Context context) {
        this.context = context;
        df= FirebaseFirestore.getInstance();
        if (context != null) {
            //UsersSQLiteDB.deleteDatabase(context);
            db = new UsersSQLiteDB(context);
            Log.d("db open",String.valueOf(db==null));
            db.open();
            Log.d("db open",String.valueOf(db==null));
        }
    }

    public void closeDataBase() {
        if(db!=null){
            db.close();
        }
    }

    //adding the users to the database
    public Boolean addManager1(User item) {
        if (db != null) {
            return db.addManager(item.getId(),item.getFirstName(),item.getLastName(),item.getUserType(),item.getPassword(),item.getPhoneNum(),item.getEmail());
        }
        return false;
    }

    //sending the user to the db
    public Boolean addCaretaker1(Caretaker item) {
        if (db != null) {
            return db.addCaretaker(item.getId(),item.getFirstName(),item.getLastName(),item.getUserType(),item.getPassword(),item.getPhoneNum(),item.getEmail(),
                    item.getMax_num_of_holidays(),item.getPrice_per_day());
        }
        return false;
    }

    public Boolean addElderly1(ElderlyClass item) {
        if (db != null) {
            return db.addElderly(item.getId(),item.getFirstName(),item.getLastName(),item.getUserType(),item.getPassword(),item.getPhoneNum(),item.getEmail(),
                    item.getBirthday(),item.getAge(),item.getAssisPhone(),item.getAddress());
        }
        return false;
    }

    //adding to the tabels
    public Boolean addMedician(Medicine item) {
        if (db != null) {
            return db.addMedician(item.getName(),item.getTotalAmount());
        }
        return false;
    }

    public Boolean addMedicianUser(Medicine item,ElderlyClass user) {
        if (db != null) {
            return db.add_medician_user(item.getName(),user.getId(),item.getTotalAmount(),item.getAthour(),"NO");
        }
        return false;
    }

    public Boolean addHolidayUser(Caretaker user,String Date) {
        if (db != null) {
            return db.add_holiday_user(user.getId(),Date);
        }
        return false;
    }

    public Boolean addPaymentUser(Caretaker user,String month,String sum) {
        if (db != null) {
            return db.add_payment_user(user.getId(),month,sum);
        }
        return false;
    }


    public User readManager(String id) {
        User result = null;
        if (db != null) {
            result = db.readManager(id);
        }
        return result;
    }



    //getting the users
    public List<User> getAllManagers() {
        List<User> result = new ArrayList<User>();
        if (db != null) {
            result = db.getAllManagers();
        }
        return result;
    }

    public List<Caretaker> getAllCaretakers() {
        List<Caretaker> result = new ArrayList<Caretaker>();
        if (db != null) {
            result = db.getAllCaretakers();
        }
        return result;
    }

    public List<ElderlyClass> getAllElderlies() {
        List<ElderlyClass> result = new ArrayList<ElderlyClass>();
        if (db != null) {
            result = db.getAllElderlies();
        }
        return result;
    }


    public void updateManager(User item) {
        if (db != null && item != null) {
            db.updateManager(item);
        }
    }

    public void updateCaretaker(Caretaker item) {
        if (db != null && item != null) {
            db.updateCaretaker(item);
        }
    }

    public void updateElderly(ElderlyClass item) {
        if (db != null && item != null) {
            db.updateElderly(item);
        }
    }


    //delete the user from the dp and the list
    public void deleteManager(User item) {
        db.open();
        if (db != null) {
            db.deleteManager(item);
            this.deleteList(item);
        }
    }



    //delete the user from the dp and the list
    public void deleteCaretaker(Caretaker item) {
        db.open();
        if (db != null) {
            db.deleteCaretaker(item);
            this.deleteList(item);
        }
    }

    //delete the user from the dp and the list
    public void deleteElderly(ElderlyClass item) {
        db.open();
        if (db != null) {
            db.deleteElderly(item);
            this.deleteList(item);
        }
    }


    public User getSelectedUser() {
        return this.selectedUser;
    }

    public void setSelectedUser(User selectedUser) {
        this.selectedUser = selectedUser;
    }

    public void removeAllPets() {
        if(db!=null){
            db.deleteAllUsers();
        }
    }
}
