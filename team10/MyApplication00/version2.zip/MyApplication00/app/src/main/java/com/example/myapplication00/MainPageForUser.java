package com.example.myapplication00;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.ui.AppBarConfiguration;

import android.os.Bundle;

import com.example.myapplication00.ByAdmin.Admin1;
import com.example.myapplication00.ByAdmin.AdminAddUser;
import com.example.myapplication00.ByAdmin.AdminEditUser;
import com.example.myapplication00.ByAdmin.DeleteUser;
import com.example.myapplication00.ByAdmin.EditSpecUser;
import com.example.myapplication00.logic_model.UsersDataBaseManager;

public class MainPageForUser extends AppCompatActivity {


    private AppBarConfiguration appBarConfiguration;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page_for_user);


        String getInput = getIntent().getStringExtra("userType");
        //calling the method to set the fragment to the specific user
        if(!getInput.equals(null))
            setFragment(getInput);



    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }



    //setting the fragment by the user type
    public void setFragment(String userType){

        if( userType.equals("manager")){//for managers
            //setting the caretaker fragment
            Manager manager= new Manager();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout ,manager).commit();
            String s="id= " + userType;


        }

        if( userType.equals("elderly Person")){//for elderly people
            //setting elderly Person fragment
            Elderly elderly = new Elderly();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout ,elderly).commit();


        }

        if( userType.equals("caretaker")){//for caretakers
            //setting the fragment to the caretaker
            Caretakers caretakers = new Caretakers();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout ,caretakers).commit();

        }if(userType.equals("admin")){ //for Admin
            //setting the fragment for the admin
            Admin1 admin1 = new Admin1();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout ,admin1).commit();
        }
        if (userType.equals("AdminAddUser")) {//for AdminAddUser Fragment
            //setting the AdminAddUser fragment
            AdminAddUser fragment = new AdminAddUser();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout, fragment).commit();

        }

        if (userType.equals("removeUser")) {//for DeleteUser Fragment
            //setting the DeleteUser fragment
            DeleteUser fragment = new DeleteUser();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout, fragment).commit();

        }

        if (userType.equals("AdminEditUser")) {//for AdminEditUser Fragment
            //setting the AdminEditUser fragment
            AdminEditUser fragment = new AdminEditUser();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout, fragment).commit();

        }

        if (userType.equals("healthServices")) {//for ElderlyHealthService Fragment
            //setting the ElderlyHealthService fragment
            ElderlyHealthService fragment = new ElderlyHealthService();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout, fragment).commit();

        }

        if (userType.equals("monitor")) {//for ElderlyMonitor Fragment
            //setting the ElderlyMonitor fragment
            ElderlyMonitor fragment = new ElderlyMonitor();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout, fragment).commit();

        }

        if (userType.equals("order")) {//for ElderlyOrder Fragment
            //setting the ElderlyOrder fragment
            ElderlyOrder fragment = new ElderlyOrder();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout, fragment).commit();

        }

        if (userType.equals("EditSpecUser")) {//for EditSpecUser Fragment
            //setting the EditSpecUser fragment
            EditSpecUser fragment = new EditSpecUser();
            getSupportFragmentManager().beginTransaction().replace(R.id.rootLayout, fragment).commit();

        }





    }




}