package com.example.myapplication00;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication00.Classes.ElderlyClass;
import com.example.myapplication00.Classes.User;
import com.example.myapplication00.logic_model.UsersDataBaseManager;

import java.util.ArrayList;
import java.util.List;


public class Caretakers extends Fragment {



    public Caretakers() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_caretakers, container, false);
        //set the card view for the caretaker user
        ListView recList =  view.findViewById(R.id.cardListCaretaker);

        //call the adapter to set the details for each elderly person
        //to change for later to recycler cardView
        Caretaker_WorkAdapter ca = new Caretaker_WorkAdapter(getContext(), createList());
        recList.setAdapter(ca);

        return view;

    }

    //create elderly persons list for the card views
    //we will change the User data to elderly data
    private List<ElderlyClass> createList() {

        List<ElderlyClass> result = null;
        List<ElderlyClass> result1 =new ArrayList<>();

        //Cursor res = myInfoDatabase.getUserdata();
        result= UsersDataBaseManager.getInstance().getAllElderlies();
        if( result.size()== 0){
            Toast.makeText(getContext(), "There is no users yet", Toast.LENGTH_SHORT).show();
        }

        Log.d("inputget",String.valueOf(result1.size()));
        return result1;

    }
}