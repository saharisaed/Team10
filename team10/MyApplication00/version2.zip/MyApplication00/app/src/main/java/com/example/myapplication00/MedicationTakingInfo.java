package com.example.myapplication00;

public class MedicationTakingInfo {

    //for each person they have a list of medication to know if its empty or how much they take
    String medicationName;
    int amount;
    String perWhat; //day,month,year
    boolean empty;

    public MedicationTakingInfo(String medicationName , int amount , String perWhat,boolean empty ) {
        this.medicationName = medicationName;
        this.amount = amount;
        this.perWhat = perWhat ;
        this.empty = empty;
    }
}
