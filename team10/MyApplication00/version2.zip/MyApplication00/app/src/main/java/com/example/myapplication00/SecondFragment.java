package com.example.myapplication00;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.autofill.CharSequenceTransformation;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication00.databinding.FragmentSecondBinding;
import com.example.myapplication00.logic_model.UsersDataBaseManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    TextInputLayout idLay,codeLay;
    Button enter;
    Spinner spinner;
    private FirebaseAuth mAuth;
    public FirebaseUser user;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_second, container, false);
        idLay = view.findViewById(R.id.textInputLayout2);
        codeLay = view.findViewById(R.id.textInputLayout);

        mAuth = FirebaseAuth.getInstance();


        enter= view.findViewById(R.id.enter);
        ArrayAdapter <CharSequence> adapter=ArrayAdapter.createFromResource(requireContext(),R.array.userType, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinner=view.findViewById(R.id.spinner2);
        enter.setOnClickListener(singInUserListener);



        return view;

    }

    private View.OnClickListener singInUserListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String email = idLay.getEditText().getText().toString();
            String password = codeLay.getEditText().getText().toString();
            Log.d("TAG", email+ " "+password);

            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.d("TAG", "signInWithEmail:success");
                                 user = mAuth.getCurrentUser();
                                 UsersDataBaseManager.getInstance().setUser(user);
                                updateUI(user);

                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w("TAG", "signInWithEmail:failure", task.getException());
                                Toast.makeText(getActivity(), task.getException().toString(),
                                        Toast.LENGTH_SHORT).show();
                                //updateUI(null);
                            }

                        }
                    });
        }
    };

    private void updateUI(FirebaseUser user) {
        if(user!=null){
            String item=null;
            item=spinner.getSelectedItem().toString();
            //cal the method to check the inputs and switch to the fragment
            confirmInputs(item);

        }
    }



    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        updateUI(currentUser);
    }

    //check Id correctness
    private boolean validateId(){

        String id = idLay.getEditText().getText().toString().trim();
        if( id.isEmpty() ){
            idLay.setError("Valid Id");
            return false;
        }
        if(id.length() != 9){
            idLay.setError("Id must be 9-digits");
            return false;
        }
        else{
            codeLay.setErrorEnabled(false);
            return true;
        }
    }


    //check the Code right now we just checked if it empty or not
    private boolean validateCode(){

        String code = codeLay.getEditText().getText().toString().trim();
        if( code.isEmpty() ){
            codeLay.setError("Valid Code");
            return false;
        }

        else{
            codeLay.setErrorEnabled(false);
            return true;
        }
    }

    //confirm the Inputs and get the  fragment to the user
    public void confirmInputs(String item){

        if(  !validateCode() )
            return;

        //start new activity
        Intent in = new Intent(getActivity(),MainPageForUser.class);
        in.putExtra("userType",item).toString();
        startActivity(in);
    }



}