
package com.example.myapplication00;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication00.Classes.Caretaker;
import com.example.myapplication00.Classes.User;

import java.util.List;

public class Manager_WorkAdapter extends ArrayAdapter<Caretaker> {

    private List<Caretaker> contactList;
    private Context context;
    public Manager_WorkAdapter(Context ctx, List<Caretaker> data){
        super(ctx,R.layout.card_for_manager);
        this.contactList = data;
        this.context = ctx;
    }

    //Setting the caretakers information for the manager user
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        final int pos = position;
        LayoutInflater inflater=LayoutInflater.from(context);
        View v=inflater.inflate(R.layout.card_for_manager, null,false);
        Log.i("Manager_WorkAdapter","current pos = " + pos);
        TextView firstName =  (TextView) v.findViewById(R.id.nameget2);
        TextView lastName = (TextView)  v.findViewById(R.id.lastNameget2);
        TextView userType = (TextView) v.findViewById(R.id.userTypeget2);
        TextView id = (TextView) v.findViewById(R.id.idget2);



        //set the buttons for setting the holidays and payment per month for the caretakers
        //we will set the functions later
        Button setHoliday = (Button) v.findViewById(R.id.SetHolidays);
        Button setPrice = (Button) v.findViewById(R.id.SetPayment);


        User user= contactList.get(pos);
        firstName.setText(user.getFirstName());
        lastName.setText(user.getLastName());
        id.setText(user.getId());
        userType.setText(user.getUserType());


        return v;
    }

    @Override
    public int getCount() {
        return contactList.size();
    }

    @Nullable
    @Override
    public Caretaker getItem(int position) {
        return contactList.get(position);
    }
}
