package com.example.myapplication00.ByAdmin;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.myapplication00.Classes.Caretaker;
import com.example.myapplication00.Classes.ElderlyClass;
import com.example.myapplication00.Classes.User;
import com.example.myapplication00.R;
import com.example.myapplication00.logic_model.UsersDataBaseManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

//fragment after choosing a user to change his details
public class EditSpecUser extends Fragment {

    UsersDataBaseManager UsersDataBaseManager;
    Button save;
    TextInputEditText idInput,fnamInput,lnameInput,codeInput,emailInput,phoneNumInput;
    User user;
    private FirebaseAuth mAuth;

    public EditSpecUser() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_edit_spec_user, container, false);
        mAuth = FirebaseAuth.getInstance();

        //getting the selected user from the list
        UsersDataBaseManager=UsersDataBaseManager.getInstance();
        user = UsersDataBaseManager.getSelectedUser();

        //getting by id when press the button save
        idInput = view.findViewById(R.id.idInput1);
        fnamInput = view.findViewById(R.id.fnamInput2);
        lnameInput = view.findViewById(R.id.lnameInput2);
        emailInput = view.findViewById(R.id.emailInput1);
        phoneNumInput = view.findViewById(R.id.phoneNum2);
        codeInput = view.findViewById(R.id.codeInput2);

        idInput.setText(user.getId());
        fnamInput.setText(user.getFirstName());
        lnameInput.setText(user.getLastName());
        phoneNumInput.setText(user.getPhoneNum());
        emailInput.setText(user.getEmail());
        codeInput.setText(user.getPassword());

        Log.d("the user ",user.getId()+" "+user.getEmail()+" "+user.getPhoneNum());

        //btn
        save = view.findViewById(R.id.savebtn);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        return view;
    }

    //update the user from the collection Firebase and the sqlite
    public void updateTheUser(){
        if(user==null)
            return;
        //update the user from the Firebase
        //getting the name of the collection
        String type=null;
        if(user.getUserType().equals("caretaker")){
            UsersDataBaseManager.getInstance().updateCaretaker((Caretaker) user);
            type="caretakers";
        }

        else if(user.getUserType().equals("elderly Person")){
            UsersDataBaseManager.getInstance().updateElderly((ElderlyClass) user);
            type="elderlies";
        }
        else if(user.getUserType().equals("manager")){
            UsersDataBaseManager.getInstance().updateManager(user);
            type="managers";
        }

        if(type!=null)
            UsersDataBaseManager.getInstance().updateUser(user,type);

        //update the user from the dp and the List


    }



}