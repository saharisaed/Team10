package com.example.myapplication00.ByAdmin;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication00.Classes.Caretaker;
import com.example.myapplication00.Classes.ElderlyClass;
import com.example.myapplication00.Classes.User;
import com.example.myapplication00.R;
import com.example.myapplication00.logic_model.UsersDataBaseManager;

import java.util.ArrayList;
import java.util.List;


//the Fragment that handle deleting User from the list by admin
public class DeleteUser extends Fragment {

    public DeleteUser() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_delete_user, container, false);
        ListView recList =  view.findViewById(R.id.cardList);
        DeleteUserAdapter ca = new DeleteUserAdapter(getContext(), createList(10));
        recList.setAdapter(ca);
        return view;

    }

    private List<User> createList(int size) {

        List<User> result = new ArrayList<>();

        //Cursor res = myInfoDatabase.getUserdata();
        for(User u :UsersDataBaseManager.getInstance().getAllManagers())
            result.add(u);
        for(Caretaker c :UsersDataBaseManager.getInstance().getAllCaretakers())
            result.add(c);

        for(ElderlyClass e :UsersDataBaseManager.getInstance().getAllElderlies())
            result.add(e);

        if( result.size()== 0){
            Toast.makeText(getContext(), "There is no users yet", Toast.LENGTH_SHORT).show();
        }
        return result;
    }

}