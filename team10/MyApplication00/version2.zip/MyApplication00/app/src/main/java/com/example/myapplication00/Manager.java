package com.example.myapplication00;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication00.Classes.Caretaker;
import com.example.myapplication00.Classes.ElderlyClass;
import com.example.myapplication00.Classes.User;
import com.example.myapplication00.logic_model.UsersDataBaseManager;

import java.util.ArrayList;
import java.util.List;


public class Manager extends Fragment {



    public Manager() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_manager, container, false);
        //set the card view for the manager user
        ListView recList =  view.findViewById(R.id.cardListManager);

        Manager_WorkAdapter ca = new Manager_WorkAdapter(getContext(), createList(10));
        recList.setAdapter(ca);

        return view;

    }

    //create caretakers list for the card views
    //we will change the User data to caretaker data
    private List<Caretaker> createList(int size) {
        List<Caretaker> result = null;
        List<Caretaker> result1 =new ArrayList<>();


        //Cursor res = myInfoDatabase.getUserdata();
        result= UsersDataBaseManager.getInstance().getAllCaretakers();
        if( result.size()== 0){
            Toast.makeText(getContext(), "There is no users yet", Toast.LENGTH_SHORT).show();
        }

        return result1;

    }
}