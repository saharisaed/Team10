package com.example.myapplication00;

import com.example.myapplication00.Classes.User;

import java.util.ArrayList;

public class ElderlyPersonInfo extends User {

    //field to the elderly persons
    int age;
    ArrayList<MedicationTakingInfo> medications;
    String password;


    public ElderlyPersonInfo() {
        super();
    }

    //constructor
    public ElderlyPersonInfo(String fname,String lname,int age,String id,String password,String phoneNum,String email) {
        super(fname,lname,id,"elderly Person",password, phoneNum,email);
        this.age = age;
        medications = new ArrayList<>();


    }



    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public ArrayList<MedicationTakingInfo> getMedications() {
        return medications;
    }

    public void setMedications(ArrayList<MedicationTakingInfo> medications) {
        this.medications = medications;
    }
}
