
package com.example.myapplication00.ByAdmin;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication00.Classes.User;
import com.example.myapplication00.MainPageForUser;
import com.example.myapplication00.R;
import com.example.myapplication00.logic_model.UsersDataBaseManager;

import java.util.List;

//When open the list of Users to Update
public class updateUserAdapter extends ArrayAdapter<User> {

    private List<User> contactList;
    private Context context;
    private User  user;
    UsersDataBaseManager UsersDataBaseManager;

    public updateUserAdapter(Context ctx, List<User> data){
        super(ctx, R.layout.card_view_for_update);
        this.contactList = data;
        this.context = ctx;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {


        LayoutInflater inflater=LayoutInflater.from(context);
        View v=inflater.inflate(R.layout.card_view_for_update, null);
        UsersDataBaseManager=UsersDataBaseManager.getInstance();
        //getting the fields
        TextView firstName =  (TextView) v.findViewById(R.id.nameget1);
        TextView lastName = (TextView)  v.findViewById(R.id.lastNameget1);
        TextView userType = (TextView) v.findViewById(R.id.userTypeget1);
        TextView id = (TextView) v.findViewById(R.id.idget1);

        user = contactList.get(position);
        firstName.setText(user.getFirstName());
        lastName.setText(user.getLastName());
        userType.setText(user.getUserType());
        id.setText(user.getId());


        //when press on the ubdate details button
        Button updatebtn = (Button) v.findViewById(R.id.updatebtn);
        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("checkMe user",user.getFirstName());
                UsersDataBaseManager.setSelectedUser(user);
                Intent in = new Intent(getContext(),MainPageForUser.class);
                in.putExtra("userType","EditSpecUser").toString();
                getContext().startActivities(new Intent[]{in});


            }
        });


        return v;
    }

    @Override
    public int getCount() {
        return contactList.size();
    }

    @Nullable
    @Override
    public User getItem(int position) {
        return contactList.get(position);
    }
}
